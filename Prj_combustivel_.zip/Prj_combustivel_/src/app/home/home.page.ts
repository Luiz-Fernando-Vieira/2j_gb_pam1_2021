import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  gas = undefined;
  alc = undefined;
  resposta = '' ;


  constructor() {}

  calcular(): void{
    const divisao = this.alc / this.gas;
    this.resposta = divisao.toString();

    if(this.resposta < '0.7'){
      this.resposta = 'Abastecer álcool é mais vantajoso';
    }else if(this.resposta === '0.7'){
      this.resposta = 'Tanto faz';
    }else{
      this.resposta = 'Abastecer gasolina é mais vantajoso';
    }

  }


}
